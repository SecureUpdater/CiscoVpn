Most recent edits:
Edit 13: February 14 – Updated patch and release information
Edit 14: February 17 – Mitigation recommendation updated, document simplified
Edit 15: February 27 - Updated external ICT, new guidance for virtual appliances
Edit 16: February 29 - Updated to include Ivanti Blog: Enhanced External Checker Tool 
Edit 17: April 20 - Updated external ICT released